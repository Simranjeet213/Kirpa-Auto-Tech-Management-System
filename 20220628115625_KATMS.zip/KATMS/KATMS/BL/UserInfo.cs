﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace KATMS.BL
{
    public static class UserInfo
    {
        public static string userName;
        public static string role;
        public static int carID;
        public static int customerID;
        public static int serviceID;
        public static int repairID;
    }
}
