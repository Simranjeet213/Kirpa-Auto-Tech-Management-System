﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KATMS.BL
{
    public class Employee
    {
        public static int empID;
        public static string firstName;
        public static string lastName;
        public static string phoneNo;
        public static string address;
        public static string emailID;
        public static string bloodGroup;
        public static string insuranceNo;
        public static double payRate;
        public static string bankNo;


        public Employee()
        {
        }
    }
}
