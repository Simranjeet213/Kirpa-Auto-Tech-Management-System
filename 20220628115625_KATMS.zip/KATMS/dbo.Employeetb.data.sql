﻿SET IDENTITY_INSERT [dbo].[Employeetb] ON
INSERT INTO [dbo].[Employeetb] ([employeeID], [firstName], [lastName], [phoneNumber], [address], [emailID], [bloodGroup], [insuranceNumber], [payPerHour], [bankAccountNumber]) VALUES (1, N'Aman', N'Solanki', N'(696) 598-5666', N'2166 Redpath, H3H 2G7.', N'aman.192@gmail.com', N'O+', N'ME9865635245', CAST(25.00 AS Decimal(5, 2)), N'SC5696665564')
INSERT INTO [dbo].[Employeetb] ([employeeID], [firstName], [lastName], [phoneNumber], [address], [emailID], [bloodGroup], [insuranceNumber], [payPerHour], [bankAccountNumber]) VALUES (2, N'Ayush', N'Patel', N'(696) 365-5666', N'5166 Redpath, H3H 2G7.', N'ayush.247@gmail.com', N'O+', N'ME9686556644', CAST(25.00 AS Decimal(5, 2)), N'TD5696885564')
SET IDENTITY_INSERT [dbo].[Employeetb] OFF
